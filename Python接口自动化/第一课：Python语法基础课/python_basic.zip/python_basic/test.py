class Course:

    def __init__(self,name,period,price,teacher):
        self.name = name
        self.period = period
        self.price = price
        self.teacher = teacher

    def __repr__(self):
        return 'repr : %s %s %s %s ' % (self.name,self.period,self.price,self.teacher)

    def __str__(self):
        return 'str : %s %s %s %s ' % (self.name, self.period, self.price, self.teacher)

a = Course(name='yinyuting', period=12, price=80, teacher='fdafd')
print(a)
