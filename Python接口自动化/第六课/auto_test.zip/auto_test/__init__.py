import os
ROOT_PATH = os.path.abspath(os.path.dirname(__file__))


