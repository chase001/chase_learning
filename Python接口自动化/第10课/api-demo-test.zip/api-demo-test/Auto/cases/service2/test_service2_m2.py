# -*- coding: utf-8 -*-#

# -------------------------------------------------------------------------------
# Name:         test_service2_m2
# Description:  
# Author            Dongtian
# Date:         2020-01-05
# -------------------------------------------------------------------------------


import unittest


class TestDemo002(unittest.TestCase):

    def test_demo1(self):
        self.assertEqual(1, 2)
