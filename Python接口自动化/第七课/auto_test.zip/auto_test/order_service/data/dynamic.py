# 该文件存放动态数据

# 优惠券的生成

# class CouponService():
#     def __init__(self, user_id, batch):
#         self.user_id = user_id
#         self.batch = batch
#
#     def get_coupon(self, user_id, batch):
#         from xxxx import BatchCoupon
#         api_obj = BatchCoupon(user_id=self.user_id,
#                               batch=self.batch)
#         api_obj.send_request()
#         return api_obj.resp.couponCode

