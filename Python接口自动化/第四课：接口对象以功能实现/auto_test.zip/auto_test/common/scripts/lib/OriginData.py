# -*- coding:utf8 -*-


class OriginData(object):
    def __init__(self, uri=None, type='swagger'):
        pass
