from .parameterized import parameterized, param, parameterized_class


def demo():
    print("This is a demo package!")


if __name__ == '__main__':
    demo()
