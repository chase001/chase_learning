class ExpectSmsCoupon(object):
    def __init__(self, ):
        self.amount= None
        self.code = None
        self.count = None
        # enable_time = DateTimeField(null=True)
        self.enable_time = None
        # end_time = DateTimeField(null=True)
        self.end_time = None
        self.id = None
        self.member_level = None
        self.min_point= None
        self.name = None
        self.note = None
        self.per_limit = None
        self.platform = None
        self.publish_count = None
        self.receive_count = None
        # start_time = DateTimeField(null=True)
        self.start_time = None
        self.type = None
        self.use_count = None
        self.use_type = None

    def xxxxx(self):
        pass
