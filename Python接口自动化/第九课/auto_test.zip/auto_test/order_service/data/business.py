# 该文件存放业务数据


class ConsOrderType(object):
    """response 状态码"""
    OK = 0
    PinTuanOrder = 0  # 拼团
    # PinTuanOrder = 1  # 拼团
    # PinTuanOrder = 2  # 拼团
    # PinTuanOrder = 3  # 拼团

