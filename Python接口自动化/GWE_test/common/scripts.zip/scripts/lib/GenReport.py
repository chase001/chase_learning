# # -*- coding:utf8 -*-
# """
# 处理-s -v -c conf/run/service.cfg  --with-html 之后生成的nosetests.html报告的log部分为层次结构
# """
#
# import string,requests,sys
#
# if sys.version_info.major == 3:
#     from bs4 import BeautifulSoup
# else:
#     from BeautifulSoup import BeautifulSoup
#
#
#
# # 如果需要新的case名称需要新new一个模块
#
#
# class TestCaseTr(object):
#     def __init__(self, name):
#         self.name = name
#
#     def



